document.addEventListener('DOMContentLoaded', function() {
    carregarResumosDashboard();

}, false);


function carregarResumosDashboard(){
    var url = "http://localhost:8080/dashboard/resumo"
    var resumo_hoteis = document.getElementById('dash_total_hoteis_cadastrados');

    var requisicao = {
        "hoteis": "total_cadastrado",
        "usuario": "joaocrm"
    }

    var xhr = new XMLHttpRequest();
    xhr.open("POST", url, true);
    xhr.setRequestHeader('Content-Type', 'application/json');
    xhr.send(JSON.stringify(requisicao));
}
